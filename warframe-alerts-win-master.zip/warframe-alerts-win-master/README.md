# warframe-alerts-win
Windows C# app tracking Warframe Alerts

[![Build Status](https://ci.appveyor.com/api/projects/status/wd768knge373635m?svg=true)](https://ci.appveyor.com/project/aliasfalse/warframe-alerts-win "Warframe Alerts App for Windows")

[![Supported by Warframe Community Developers](https://raw.githubusercontent.com/WFCD/banner/master/banner.png)](https://github.com/WFCD "Supported by Warframe Community Developers")
